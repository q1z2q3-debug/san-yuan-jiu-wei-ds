/* ============================================================
 * 三元九维中医辨证推演系统 · 数据层
 * 来源：《三元九维状态编码规则》技术手册 + 《方剂向量标注表.xlsx》(11表)
 * 标注[补充]的部分为按文档范式创新补全的数据（症状映射、药材库、禁忌结构化）
 * ============================================================ */
"use strict";

const DATA = {};

/* ---------- 1. 九维定义 ---------- */
DATA.dimensions = [
  {id:1, key:"d1", name:"本体维", layer:"内核层", couple:null,
   states:["潜藏/未确立/收敛","平衡/自我调节/柔韧","显化/自我确认强/刚性"],
   tcm:["正气未复/根基不固/元气大虚","正气存内/阴阳调和/根基稳固","正气充盛/邪正交争剧烈/刚性代偿"]},
  {id:2, key:"d2", name:"时间维", layer:"内核层", couple:"时位耦合(d3)",
   states:["过去/沉淀/回顾","现在/过渡/当下","未来/紧迫/前瞻"],
   tcm:["病久入深/慢性消耗","病程适中/反应适时/当下可调节","病急初起/反应过速/紧迫感驱动"]},
  {id:3, key:"d3", name:"空间维", layer:"内核层", couple:"时位耦合(d2)",
   states:["内收/闭塞/浅层","可开可阖/中和","外展/扩张/深层"],
   tcm:["表闭/里结/空间受限/边界失守","营卫调和/开阖有度/边界健全","邪气外达/深入脏腑/空间充分展开"]},
  {id:4, key:"d4", name:"能量维", layer:"动力层", couple:"能信耦合(d5)",
   states:["潜藏/不足/抑制","流动/适中/可持续","释放/亢盛/消耗"],
   tcm:["阳气虚衰/能量匮乏/机能减退","气血通畅/能量适中/机能正常","阳热亢盛/虚火上炎/能量透支"]},
  {id:5, key:"d5", name:"信息维", layer:"动力层", couple:"能信耦合(d4)",
   states:["隐/闭塞/混沌","清晰/适中/过滤","明/过载/碎片"],
   tcm:["痰蒙清窍/信息阻滞/感知迟钝","神明清晰/信息有序/感知灵敏","热扰神明/信息过载/感知过敏"]},
  {id:6, key:"d6", name:"关系维", layer:"动力层", couple:"群序耦合(d7)",
   states:["孤立/不通/封闭","交互/协调/必要连接","共生/过度外扩/纠缠"],
   tcm:["表里不通/脏腑失调/营卫不和","脏腑协调/营卫和合/内外通达","邪气扩散/关系紊乱/内外交困"]},
  {id:7, key:"d7", name:"秩序维", layer:"动力层", couple:"群序耦合(d6)",
   states:["混沌/失序/无结构","规则/中和/最小结构","结构化/僵化/控制"],
   tcm:["升降失常/开阖失度/阴阳失调","升降有序/开阖有度/阴阳平衡","燥结/瘀阻/规则僵化/通路闭塞"]},
  {id:8, key:"d8", name:"价值维", layer:"表达层", couple:"知行耦合(d9)",
   states:["无意义/迷失/空愿","权衡/有方向/锚定","意义确立/过度执取"],
   tcm:["正气方向迷失/精气不固","正气有序/精气内守/方向明确","虚火妄动/执着于某一方"]},
  {id:9, key:"d9", name:"行动维", layer:"表达层", couple:"知行耦合(d8)",
   states:["静止/无力/塌陷","试探/适中/节奏","执行/亢奋/耗散"],
   tcm:["气虚无力/机能抑制/行动停滞","气血运行有序/机能适度活跃","邪气亢盛/虚性兴奋/行动失度"]}
];
DATA.DIM_NAMES = DATA.dimensions.map(d=>d.key+d.name.replace("维",""));

/* ---------- 2. 六大吸引子 ---------- */
DATA.attractors = [
  {name:"中和", vec:[1,1,1,1,1,1,1,1,1], formula:"桂枝汤",
   scene:"系统失衡、方向不清、需要恢复弹性",
   cond:"多维差值大，耦合对冲突明显，d7/d8/d3不足",
   switchPre:"系统乱，先回中和", risk:"中和过久不选择方向，易变惰性稳态"},
  {name:"显化", vec:[1,2,1,2,2,1,1,1,2], formula:"麻黄汤/白虎汤",
   scene:"目标明确、资源充足、需要输出成果（表闭待宣、实热待清）",
   cond:"d1/d8/d7已稳定，d4/d9有上升空间",
   switchPre:"方向清、结构稳，才去显化", risk:"秩序不足时强显化→亢奋耗散"},
  {name:"潜藏", vec:[0,1,0,0,1,0,0,0,0], formula:"六味地黄丸/四逆汤",
   scene:"能量透支、外部不确定、需要修复沉淀",
   cond:"d4/d9过高，d3/d1不足，外部反馈混乱",
   switchPre:"能量亏、空间小，先进潜藏", risk:"潜藏过久不输出，易变萎靡"},
  {name:"关系", vec:[1,1,1,1,1,2,1,1,1], formula:"—",
   scene:"需要协作、共识、组织动员（脏腑连接失调）",
   cond:"d6/d8需要上升，d7能承接，d1不低于1",
   switchPre:"问题在连接、本体又稳，再入关系", risk:"d1低时入关系→讨好依附；d7低→热闹无效"},
  {name:"枢转", vec:[1,2,1,1,1,0,0,1,1], formula:"小柴胡汤",
   scene:"系统卡在中间、需要恢复切换权（半表半里）",
   cond:"d6/d7失序，d2波动，d3居中半表半里",
   switchPre:"枢机不利、进退维谷", risk:"不恢复切换权，系统持续卡滞"},
  {name:"升举", vec:[0,1,0,0,1,0,0,1,0], formula:"补中益气汤",
   scene:"中气下陷、清阳不升、行动塌陷",
   cond:"d1/d4/d7/d9偏低，d3上升空间塌陷",
   switchPre:"本体虚、升举无力", risk:"不补而强升→无根上提、虚阳外越"}
];

/* ---------- 3. 十四首经典方剂（Excel·方剂向量标注表） ---------- */
/* flags[补充]: strongSweat强发汗 / strongAttack强攻下 / strongManifest强显化 / preg妊娠 */
DATA.formulas = [
 {name:"桂枝汤", jun:["桂枝"], chen:["芍药"], zuo:["生姜","大枣"], shi:["甘草"],
  vec:[1,2,0,1,1,2,0,1,2], attractor:"中和",
  path:"修复d3边界、d7秩序 → 调和d6营卫关系 → 收敛d9行动 → 进入中和态",
  contra:"d9=0且d3=0(表闭无汗不宜)；d4极高属实热不宜；阴虚阳亢慎用",
  apply:"营卫不和、开阖失度", note:"一开一合，恢复自我调节；桂枝主开，芍药主合，甘草调和", flags:{}},
 {name:"六味地黄丸", jun:["熟地黄"], chen:["山茱萸","山药"], zuo:["泽泻","牡丹皮"], shi:["茯苓"],
  vec:[1,1,0,2,1,1,0,1,2], attractor:"潜藏",
  path:"补d3深层空间 → 恢复d7封藏秩序 → 泄浊清热(d4、d9) → 进入潜藏修复态",
  contra:"阳虚寒盛忌用；脾虚湿盛慎用；表证未解不宜",
  apply:"肾阴不足、虚火上炎", note:"补阴固摄，先藏后养；熟地填补，山茱萸收敛，泽泻泄浊，茯苓运化", flags:{}},
 {name:"麻黄汤", jun:["麻黄"], chen:["桂枝"], zuo:["杏仁"], shi:["甘草"],
  vec:[1,2,0,1,1,0,0,1,0], attractor:"显化",
  path:"开d3表闭 → 宣通d6肺气 → 恢复d7升降秩序 → 启动d9有序外解(发汗) → 回归中和",
  contra:"表虚自汗忌用；阴虚阳亢忌用；衄血者忌用；心肺虚弱慎用",
  apply:"风寒束表、肺气不宣", note:"开表宣肺，有序外解；麻黄开表，桂枝助阳，杏仁降气，甘草守中",
  flags:{strongSweat:true, strongManifest:true}},
 {name:"小柴胡汤", jun:["柴胡"], chen:["黄芩"], zuo:["半夏","生姜","人参","大枣"], shi:["甘草"],
  vec:[1,2,1,1,1,0,0,1,1], attractor:"枢转",
  path:"恢复d6枢转、d7秩序 → 透达郁热(d4清透) → 和降胃气(d9有序) → 扶正守中(d1、d8) → 回归中和",
  contra:"少阳证未显不宜；纯表证或纯里证不宜；实热壅盛慎用",
  apply:"少阳枢机不利、胆胃不和", note:"修复枢机切换能力；柴胡透达，黄芩清泄，参枣草扶正，夏姜和胃", flags:{}},
 {name:"补中益气汤", jun:["黄芪"], chen:["人参","白术","炙甘草"], zuo:["当归","陈皮"], shi:["升麻","柴胡"],
  vec:[0,1,0,0,1,0,0,1,0], attractor:"升举",
  path:"补d1本体、d4能量 → 建d7秩序 → 开d3上升空间 → 通d6上下连接 → 恢复d9行动 → 回归中和",
  contra:"实证忌用；阴虚阳亢忌用；气滞胀满慎用；外感发热忌用",
  apply:"脾胃气虚、清阳下陷", note:"补中升阳，重建上升通道；黄芪补气升阳，参术草建中，归陈理气，升柴引经", flags:{}},
 {name:"四逆汤", jun:["附子"], chen:["干姜"], zuo:[], shi:["甘草"],
  vec:[0,1,0,0,1,0,0,0,0], attractor:"潜藏",
  path:"温d4阳气 → 回阳救逆 → d9收敛 → d1根基重建",
  contra:"表虚自汗忌；阴虚阳亢忌；真热假寒忌",
  apply:"少阴病寒化证，四肢厥逆脉微细", note:"回阳救逆第一方；附子干姜甘草，大辛大热回阳",
  flags:{toxHerb:true}},
 {name:"理中丸", jun:["人参"], chen:["白术"], zuo:["干姜"], shi:["甘草"],
  vec:[0,1,0,0,1,0,0,0,0], attractor:"潜藏",
  path:"补d1中气 → 温d4中寒 → 建d7运化 → 恢复升降",
  contra:"实热积滞忌；阴虚内热忌",
  apply:"太阴病，腹满而吐食不下，自利不渴", note:"温中散寒，补气健脾", flags:{}},
 {name:"逍遥散", jun:["柴胡"], chen:["当归","白芍"], zuo:["白术","茯苓","甘草","薄荷","生姜"], shi:[],
  vec:[1,1,1,1,1,1,1,1,1], attractor:"枢转",
  path:"疏d6肝郁 → 养d1肝血 → 健d7脾胃 → 调和气血",
  contra:"湿热内蕴忌；阴虚火旺慎用",
  apply:"肝郁血虚脾弱证，胁痛畏寒食少", note:"疏肝健脾养血，调和肝脾", flags:{}},
 {name:"血府逐瘀汤", jun:["桃仁","红花"], chen:["当归","生地","川芎","赤芍"], zuo:["牛膝","桔梗","柴胡","枳壳","甘草"], shi:[],
  vec:[1,1,1,1,1,1,1,1,1], attractor:"枢转",
  path:"活血d6化瘀 → 通d3脉络 → 调d7升降 → d9有序",
  contra:"孕妇禁用；出血倾向慎用",
  apply:"胸中血瘀证，胸痛头痛日久", note:"活血化瘀，行气止痛",
  flags:{preg:"forbid", bleedCaution:true}},
 {name:"补阳还五汤", jun:["黄芪"], chen:["当归尾","赤芍","地龙","川芎","桃仁","红花"], zuo:[], shi:[],
  vec:[0,1,0,0,1,0,0,0,0], attractor:"升举",
  path:"大补d1元气 → 推动d9行动 → 通d3脉络 → 恢复功能",
  contra:"阴虚阳亢忌；出血急性期慎用",
  apply:"中风后遗症，气虚血瘀证", note:"补气活血通络，黄芪为君重用",
  flags:{bleedCaution:true}},
 {name:"龙胆泻肝汤", jun:["龙胆草"], chen:["黄芩","栀子"], zuo:["泽泻","木通","车前子","当归","生地","柴胡"], shi:["甘草"],
  vec:[1,2,1,2,2,1,1,1,1], attractor:"显化",
  path:"清d4肝胆实热 → 利d5湿热下行 → d7疏泄恢复",
  contra:"脾胃虚寒忌；阴虚津伤忌",
  apply:"肝胆实火上炎、湿热下注证", note:"清泻肝胆，利湿清热",
  flags:{strongManifest:true}},
 {name:"茵陈蒿汤", jun:["茵陈蒿"], chen:["栀子"], zuo:["大黄"], shi:[],
  vec:[1,2,1,2,2,1,1,1,1], attractor:"显化",
  path:"清热d4利湿 → 通d3泄热 → d7退黄 → d5浊下行",
  contra:"寒湿黄疸忌；脾胃虚寒忌",
  apply:"阳黄(湿热黄疸)，身黄目黄尿黄", note:"清热利湿退黄，治阳黄第一方",
  flags:{preg:"caution"}},
 {name:"白虎汤", jun:["石膏"], chen:["知母"], zuo:["甘草"], shi:["粳米"],
  vec:[1,2,1,2,2,1,1,1,2], attractor:"显化",
  path:"大清气分d4热 → 生津d5润燥 → d7清热 → d9外透",
  contra:"阳明虚寒忌；表证未解忌",
  apply:"阳明经证，大热大汗大渴脉洪大", note:"清热生津，辛寒清气", flags:{}},
 {name:"大承气汤", jun:["大黄"], chen:["芒硝"], zuo:["厚朴","枳实"], shi:[],
  vec:[1,2,1,2,2,2,2,1,2], attractor:"显化",
  path:"攻下d3实热 → d9通降 → d7泄实 → d5浊排出",
  contra:"表证未解忌；孕妇忌；体虚慎用",
  apply:"阳明腑实证，痞满燥实坚", note:"峻下热结，急下行阴",
  flags:{strongAttack:true, preg:"forbid"}}
];

/* ---------- 4. 症状→九维映射表 [补充] ----------
 * 按《编码规则》§12.3"辨证即诊断"范式标定：
 * votes: {维度索引0-8: 票值}，正值推向2(阳/显)，负值推向0(阴/潜)，绝对值为置信权重
 */
DATA.symptomGroups = [
 {group:"全身寒热", items:[
  {n:"恶寒明显添衣不解", v:{3:-1, 1:+1}, tag:"寒"},
  {n:"四肢厥冷", v:{3:-2, 8:-1, 0:-1}, tag:"寒"},
  {n:"发热身热", v:{3:+2}, tag:"热"},
  {n:"寒热往来", v:{1:+1, 5:-2, 6:-1}, tag:"少阳"},
  {n:"畏寒喜暖", v:{3:-2, 0:-1}, tag:"寒"},
  {n:"五心烦热", v:{3:+2, 2:-1}, tag:"热"},
  {n:"潮热盗汗", v:{3:+1, 2:-1, 6:-1}, tag:"热"},
  {n:"自汗恶风", v:{2:-1, 6:-1, 0:-1}, tag:"表虚"},
  {n:"无汗身痛", v:{2:-2, 1:+1}, tag:"表实"}]},
 {group:"头身胸腹", items:[
  {n:"头晕目眩", v:{0:-1, 3:-1}},
  {n:"头胀头痛面红目赤", v:{3:+2, 8:+1}},
  {n:"耳鸣如蝉", v:{0:-1, 2:-1}},
  {n:"胸闷", v:{2:-1, 5:-1, 4:+1}},
  {n:"胸胁胀满", v:{5:-2, 6:-1, 2:-1}},
  {n:"善太息情绪抑郁", v:{5:-2, 7:-1}},
  {n:"心悸怔忡", v:{4:+1, 6:-1}},
  {n:"刺痛固定拒按", v:{2:-1, 5:-1, 6:-1}, tag:"瘀"},
  {n:"脘腹胀痛拒按", v:{6:+2, 3:+1}, tag:"实"},
  {n:"腹痛喜温喜按", v:{3:-2, 0:-1}, tag:"寒虚"},
  {n:"恶心呕吐", v:{6:-1, 8:+1}},
  {n:"腹满食不下", v:{0:-1, 6:-1, 3:-1}},
  {n:"腰膝酸软", v:{2:-2, 0:-1}},
  {n:"肢体麻木", v:{5:-1, 2:-1, 8:-1}},
  {n:"半身不遂", v:{8:-2, 5:-1, 2:-1}},
  {n:"筋脉抽搐", v:{8:+1, 2:-1}}]},
 {group:"饮食二便", items:[
  {n:"口干口苦", v:{3:+1, 4:+1}, tag:"热"},
  {n:"咽干口渴多饮", v:{3:+1, 2:-1}, tag:"热"},
  {n:"口淡不渴", v:{3:-1}, tag:"寒"},
  {n:"痰多质稠", v:{4:+2, 6:-1}, tag:"痰湿"},
  {n:"呕吐清水", v:{3:-1, 4:+1}, tag:"寒"},
  {n:"大便溏泄", v:{0:-1, 6:-1, 3:-1}, tag:"虚寒"},
  {n:"便秘燥结", v:{6:+2, 3:+1, 2:-1}, tag:"实热"},
  {n:"小便短黄", v:{3:+1, 4:+1}, tag:"热"},
  {n:"小便清长", v:{3:-1}, tag:"寒"},
  {n:"夜尿频多", v:{0:-1, 6:-1}},
  {n:"身目发黄", v:{3:+1, 4:+2, 6:-1}, tag:"湿热"},
  {n:"水肿", v:{4:+1, 6:-1, 2:-1}}]},
 {group:"睡眠情志", items:[
  {n:"失眠多梦", v:{4:+1, 8:+1, 6:-1}},
  {n:"心烦易惊", v:{4:+1, 6:-1}},
  {n:"嗜睡困倦", v:{8:-1, 4:+1, 3:-1}},
  {n:"神疲乏力", v:{0:-1, 3:-1, 8:-1}, tag:"虚"},
  {n:"气短懒言", v:{0:-1, 8:-1, 3:-1}, tag:"虚"},
  {n:"健忘", v:{0:-1, 4:-1}},
  {n:"烦躁不安", v:{3:+1, 8:+1, 4:+1}}]},
 {group:"形体皮肤", items:[
  {n:"形体肥胖身重", v:{4:+2, 6:-1, 8:-1}, tag:"痰湿"},
  {n:"面垢油光痤疮", v:{3:+2, 4:+2}, tag:"湿热"},
  {n:"面色晦暗", v:{5:-2, 6:-1, 2:-1}, tag:"瘀"},
  {n:"皮肤干燥", v:{2:-1, 3:+1}},
  {n:"皮肤瘙痒疹出", v:{2:+1, 8:+1}},
  {n:"咳喘气逆", v:{5:-1, 6:-1, 8:+1}}]},
 {group:"舌象", items:[
  {n:"舌淡苔白", v:{3:-2}, tag:"寒"},
  {n:"舌红苔黄", v:{3:+2, 4:+1}, tag:"热"},
  {n:"舌红绛少苔", v:{3:+2, 2:-2}, tag:"阴虚"},
  {n:"舌胖大齿痕", v:{4:+1, 6:-1, 0:-1}, tag:"痰湿"},
  {n:"苔厚腻", v:{4:+2, 6:-1}, tag:"痰湿"},
  {n:"舌紫暗有瘀斑", v:{5:-2, 6:-1, 2:-1}, tag:"瘀"},
  {n:"苔薄白而干", v:{2:-1, 3:+1}},
  {n:"舌淡紫湿润", v:{3:-1, 5:-1}, tag:"寒"}]},
 {group:"脉象", items:[
  {n:"脉浮", v:{2:+1, 1:+1}, tag:"表"},
  {n:"脉沉", v:{2:-1}, tag:"里"},
  {n:"脉迟", v:{3:-1}, tag:"寒"},
  {n:"脉数", v:{3:+1}, tag:"热"},
  {n:"脉虚弱无力", v:{0:-1, 3:-1, 8:-1}, tag:"虚"},
  {n:"脉有力", v:{3:+1, 8:+1}, tag:"实"},
  {n:"脉弦", v:{5:-1, 6:-1}, tag:"气郁"},
  {n:"脉滑", v:{4:+1}, tag:"痰湿"},
  {n:"脉细", v:{2:-1, 0:-1}, tag:"虚"},
  {n:"脉涩结代", v:{5:-1, 6:-1, 2:-1}, tag:"瘀"},
  {n:"脉洪大", v:{3:+2, 8:+1}, tag:"实热"}]},
 {group:"病程与情境", items:[
  {n:"新病急起(≤3日)", v:{1:+1}},
  {n:"久病慢性(>1月)", v:{1:-1, 0:-1}},
  {n:"病情反复波动", v:{1:+1, 6:-1}},
  {n:"妊娠状态", special:"pregnant"},
  {n:"出血倾向/衄血", special:"bleeding"},
  {n:"过敏体质易疹", v:{0:-1, 6:-1, 2:+1}}]}
];

/* ---------- 5. 宏观辨证标签（八纲/六经/体质，Excel三张映射表） ---------- */
DATA.bagang = [
 {n:"阴证", vec:[0,1,0,0,1,0,0,0,0], attr:"潜藏", rule:"温补扶正", f:"四逆汤", note:"阳气衰微，四肢厥逆；需大温大补"},
 {n:"阳证", vec:[2,2,2,2,2,2,1,2,2], attr:"显化(偏亢)", rule:"清热泻火", f:"白虎汤", note:"阳明经热盛；大热大汗大渴脉洪大"},
 {n:"表证", vec:[1,2,2,1,1,2,1,1,1], attr:"显化", rule:"解表发汗", f:"麻黄汤/桂枝汤", note:"风寒/风热在表；有汗无汗分伤寒伤风"},
 {n:"里证", vec:[1,1,0,1,1,0,0,1,1], attr:"多种", rule:"治里", f:"大承气汤/理中丸", note:"里实/里虚；寒热虚实各异"},
 {n:"寒证", vec:[0,1,0,0,1,0,0,0,0], attr:"潜藏", rule:"温里散寒", f:"理中丸/四逆汤", note:"实寒/虚寒；寒者热之"},
 {n:"热证", vec:[1,2,1,2,2,1,1,1,2], attr:"显化", rule:"清热生津", f:"白虎汤", note:"实热/虚热；热者寒之"},
 {n:"虚证", vec:[0,1,0,0,1,0,0,0,0], attr:"潜藏", rule:"补益扶正", f:"四君子汤/补中益气汤", note:"气虚/血虚/阴虚/阳虚各异"},
 {n:"实证", vec:[1,2,1,2,2,2,2,1,2], attr:"显化", rule:"攻邪泄实", f:"大承气汤", note:"实热/实寒/痰饮/瘀血各异"}
];
DATA.liujing = [
 {n:"太阳病", vec:[1,2,0,1,1,2,0,1,2], rule:"解表发汗、调和营卫", f:"麻黄汤/桂枝汤", note:"太阳主表；伤寒/伤风"},
 {n:"阳明病", vec:[1,2,1,2,2,1,2,1,2], rule:"清热生津、攻下实热", f:"白虎汤/大承气汤", note:"经证/腑证；四大症"},
 {n:"少阳病", vec:[1,2,1,1,1,0,0,1,1], rule:"和解少阳、疏利枢机", f:"小柴胡汤", note:"半表半里；寒热往来胸胁苦满"},
 {n:"太阴病", vec:[0,1,0,0,1,0,0,0,0], rule:"温中健脾、祛寒化湿", f:"理中丸/四逆汤", note:"病多在脾；腹满而吐食不下"},
 {n:"少阴病", vec:[0,1,0,0,1,0,0,0,1], rule:"温阳救逆、滋阴降火", f:"四逆汤/黄连阿胶汤", note:"寒化证/热化证"},
 {n:"厥阴病", vec:[1,2,1,1,2,2,0,1,2], rule:"调和寒热、疏肝理气", f:"乌梅丸/柴胡桂枝干姜汤", note:"阴尽阳生；最复杂之证"}
];
DATA.tizhi = [
 {n:"平和质", vec:[1,1,1,1,1,1,1,1,1], rule:"维持平衡、顺应四时", f:"不需服药，养生即可", note:"阴平阳秘，精神乃治"},
 {n:"气虚质", vec:[0,1,0,0,1,0,0,0,0], rule:"补气健脾、升阳举陷", f:"补中益气汤/四君子汤", note:"易感冒易疲劳，自汗"},
 {n:"阳虚质", vec:[0,0,0,0,1,0,0,0,0], rule:"温阳散寒、补火助运", f:"金匮肾气丸/理中丸", note:"畏寒肢冷，大便溏薄"},
 {n:"阴虚质", vec:[1,1,0,2,1,1,0,1,2], rule:"滋阴降火、填精益髓", f:"六味地黄丸/知柏地黄丸", note:"手足心热，潮热盗汗"},
 {n:"痰湿质", vec:[1,1,0,1,2,1,0,0,1], rule:"健脾燥湿、化痰泄浊", f:"二陈汤/参苓白术散", note:"形体肥胖，胸闷痰多"},
 {n:"湿热质", vec:[1,2,1,2,2,1,0,1,2], rule:"清热利湿、解毒排脓", f:"茵陈蒿汤/龙胆泻肝汤", note:"面垢油光，口苦苔黄腻"},
 {n:"血瘀质", vec:[1,1,0,1,1,0,0,1,1], rule:"活血化瘀、通经止痛", f:"血府逐瘀汤/桃红四物汤", note:"面色晦暗，舌质紫暗"},
 {n:"气郁质", vec:[1,1,0,1,1,0,0,0,1], rule:"疏肝解郁、调畅气机", f:"逍遥散/柴胡疏肝散", note:"情绪抑郁，胸胁胀满"},
 {n:"特禀质", vec:[0,1,0,1,1,1,0,1,1], rule:"固本培元、祛风解毒", f:"玉屏风散", note:"易过敏，哮喘荨麻疹"}
];

/* ---------- 6. 药材库 [补充]（依据《编码规则》§15药性向量映射整理） ---------- */
DATA.herbs = {
 "麻黄":{qi:"温",wei:"辛、微苦",jing:"肺、膀胱",act:"发汗解表、宣肺平喘",dims:"d3开表 d9宣散"},
 "桂枝":{qi:"温",wei:"辛、甘",jing:"心、肺、膀胱",act:"发汗解肌、温通经脉",dims:"d3↑ d6↑ d9↑",vec:[1,2,1,1,1,2,1,1,2]},
 "芍药":{qi:"微寒",wei:"苦、酸",jing:"肝、脾",act:"敛阴和营、柔肝止痛",dims:"d3收敛 d9↓ d7↑ d8↑",vec:[1,1,1,1,1,1,1,1,1]},
 "白芍":{qi:"微寒",wei:"苦、酸",jing:"肝、脾",act:"养血敛阴、柔肝止痛",dims:"d7收敛 d3固涩"},
 "赤芍":{qi:"微寒",wei:"苦",jing:"肝",act:"清热凉血、散瘀止痛",dims:"d6通络 d4清"},
 "生姜":{qi:"温",wei:"辛",jing:"肺、脾、胃",act:"解表散寒、温中止呕",dims:"d3开 d9宣"},
 "大枣":{qi:"温",wei:"甘",jing:"脾、胃",act:"补中益气、养血安神",dims:"d1补 d7和 d8养"},
 "甘草":{qi:"平",wei:"甘",jing:"心、肺、脾、胃",act:"调和诸药、补脾益气",dims:"全局调和",vec:[1,1,1,1,1,1,1,1,1],tox:"十八反(甘遂/大戟/海藻/芫花)"},
 "炙甘草":{qi:"温",wei:"甘",jing:"心、肺、脾、胃",act:"补脾和胃、益气复脉",dims:"d1补 d7和"},
 "附子":{qi:"热",wei:"辛、甘",jing:"心、肾、脾",act:"回阳救逆、补火助阳",dims:"d4↑ d9↑",vec:[0,1,0,2,1,0,0,0,2],tox:"大毒(炮制后用)",preg:"慎用"},
 "干姜":{qi:"热",wei:"辛",jing:"脾、胃、心、肺",act:"温中散寒、回阳通脉",dims:"d4升 d9温通",preg:"慎用"},
 "人参":{qi:"温",wei:"甘、微苦",jing:"脾、肺、心",act:"大补元气、复脉固脱",dims:"d1补 d4升 d8养",tox:"反藜芦 畏五灵脂/皂角"},
 "黄芪":{qi:"温",wei:"甘",jing:"脾、肺",act:"补气升阳、固表利水",dims:"d1↑ d4↑ d7建"},
 "白术":{qi:"温",wei:"苦、甘",jing:"脾、胃",act:"健脾益气、燥湿利水",dims:"d1补 d7运化"},
 "茯苓":{qi:"平",wei:"甘、淡",jing:"心、脾、肾",act:"利水渗湿、健脾宁心",dims:"d7渗湿 d5利浊"},
 "当归":{qi:"温",wei:"甘、辛",jing:"肝、心、脾",act:"补血活血、调经止痛",dims:"d1养 d6通"},
 "当归尾":{qi:"温",wei:"甘、辛",jing:"肝、心、脾",act:"活血祛瘀",dims:"d6通 d3通"},
 "川芎":{qi:"温",wei:"辛",jing:"肝、胆、心包",act:"活血行气、祛风止痛",dims:"d6通 d9行"},
 "熟地黄":{qi:"微温",wei:"甘",jing:"肝、肾",act:"补血滋阴、益精填髓",dims:"d3深层补 d7封藏"},
 "生地":{qi:"寒",wei:"甘",jing:"心、肝、肾",act:"清热凉血、养阴生津",dims:"d4清 d3滋"},
 "山茱萸":{qi:"微温",wei:"酸、涩",jing:"肝、肾",act:"补益肝肾、收涩固脱",dims:"d7收敛 d3固涩"},
 "山药":{qi:"平",wei:"甘",jing:"脾、肺、肾",act:"补脾养胃、生津益肺",dims:"d1补 d7固"},
 "泽泻":{qi:"寒",wei:"甘、淡",jing:"肾、膀胱",act:"利水渗湿、泄热",dims:"d7渗湿 d5利浊 d4泄"},
 "牡丹皮":{qi:"微寒",wei:"苦、辛",jing:"心、肝、肾",act:"清热凉血、活血化瘀",dims:"d4清 d6通"},
 "柴胡":{qi:"微寒",wei:"辛、苦",jing:"肝、胆、肺",act:"疏散退热、疏肝解郁、升举阳气",dims:"d6枢转 d3升"},
 "黄芩":{qi:"寒",wei:"苦",jing:"肺、胆、脾、大肠",act:"清热燥湿、泻火解毒",dims:"d4降 d5清",tox:"十九畏(川椒)"},
 "半夏":{qi:"温",wei:"辛",jing:"脾、胃、肺",act:"燥湿化痰、降逆止呕",dims:"d7降逆 d5化浊",tox:"有毒(炮制) 反乌头",preg:"慎用"},
 "升麻":{qi:"微寒",wei:"辛、微甘",jing:"肺、脾、胃、大肠",act:"发表透疹、升举阳气",dims:"d3上升 d6升提"},
 "陈皮":{qi:"温",wei:"苦、辛",jing:"脾、肺",act:"理气健脾、燥湿化痰",dims:"d6疏 d7运"},
 "杏仁":{qi:"微温",wei:"苦",jing:"肺、大肠",act:"降气止咳、润肠通便",dims:"d9降逆 d7肃降",tox:"小毒"},
 "薄荷":{qi:"凉",wei:"辛",jing:"肺、肝",act:"疏散风热、清利头目",dims:"d3外达 d9发散"},
 "桃仁":{qi:"平",wei:"苦、甘",jing:"心、肝、大肠",act:"活血祛瘀、润肠通便",dims:"d6化瘀 d3通",tox:"小毒",preg:"慎用"},
 "红花":{qi:"温",wei:"辛",jing:"心、肝",act:"活血通经、散瘀止痛",dims:"d6通 d9行",preg:"慎用"},
 "牛膝":{qi:"平",wei:"苦、甘、酸",jing:"肝、肾",act:"逐瘀通经、引血下行",dims:"d9下行 d6通",preg:"慎用"},
 "桔梗":{qi:"平",wei:"苦、辛",jing:"肺",act:"宣肺利咽、祛痰排脓",dims:"d3升 d6宣"},
 "枳壳":{qi:"微寒",wei:"苦、辛",jing:"脾、胃、大肠",act:"理气宽中、行滞消胀",dims:"d7降气 d6行"},
 "枳实":{qi:"微寒",wei:"苦、辛",jing:"脾、胃、大肠",act:"破气消积、化痰散痞",dims:"d7破滞 d9下行",preg:"慎用"},
 "厚朴":{qi:"温",wei:"苦、辛",jing:"脾、胃、肺、大肠",act:"燥湿消痰、下气除满",dims:"d7降 d5化浊"},
 "大黄":{qi:"寒",wei:"苦",jing:"脾、胃、大肠、肝、心包",act:"泻下攻积、清热泻火、逐瘀",dims:"d4↓ d5↓ d7↓ d9↓",vec:[1,2,1,2,2,2,2,0,2],preg:"慎用",tox:"十九畏(密陀僧)"},
 "芒硝":{qi:"寒",wei:"咸、苦",jing:"胃、大肠",act:"泻下通便、润燥软坚",dims:"d7软坚 d3散结",preg:"慎用",tox:"十九畏(硫黄/牙硝类)"},
 "石膏":{qi:"大寒",wei:"甘、辛",jing:"肺、胃",act:"清热泻火、除烦止渴",dims:"d4降 d5清透"},
 "知母":{qi:"寒",wei:"苦、甘",jing:"肺、胃、肾",act:"清热泻火、滋阴润燥",dims:"d4降 d3滋"},
 "粳米":{qi:"平",wei:"甘",jing:"脾、胃",act:"益胃生津、护中守正",dims:"d1守中"},
 "龙胆草":{qi:"寒",wei:"苦",jing:"肝、胆",act:"清热燥湿、泻肝胆火",dims:"d4猛降 d5清"},
 "栀子":{qi:"寒",wei:"苦",jing:"心、肺、三焦",act:"泻火除烦、清热利湿",dims:"d4降 d5清 d7利"},
 "茵陈蒿":{qi:"微寒",wei:"苦、辛",jing:"脾、胃、肝、胆",act:"清利湿热、退黄疸",dims:"d5浊下行 d4清"},
 "木通":{qi:"寒",wei:"苦",jing:"心、小肠、膀胱",act:"利尿通淋、清心火",dims:"d5利浊 d4降"},
 "车前子":{qi:"微寒",wei:"甘",jing:"肝、肾、肺、小肠",act:"清热利尿、渗湿",dims:"d7渗湿 d5利浊"},
 "地龙":{qi:"寒",wei:"咸",jing:"肝、脾、膀胱",act:"清热定惊、通络",dims:"d3通络 d6通"},
 "黄连":{qi:"寒",wei:"苦",jing:"心、脾、胃、胆",act:"清热燥湿、泻火解毒",dims:"d4降 d5清",tox:"十九畏(川椒)"},
 "金银花":{qi:"寒",wei:"甘",jing:"肺、心、胃",act:"清热解毒、疏散风热",dims:"d4微降 d5微清"},
 "连翘":{qi:"微寒",wei:"苦",jing:"肺、心、小肠",act:"清热解毒、消肿散结",dims:"d4清 d3散结"},
 "防风":{qi:"微温",wei:"辛、甘",jing:"膀胱、肝、脾",act:"祛风解表、胜湿",dims:"d3外达 d6祛风"},
 "酸枣仁":{qi:"平",wei:"甘、酸",jing:"心、肝、胆",act:"养心补肝、宁心安神",dims:"d7安定 d8锚定"},
 "龙骨":{qi:"平",wei:"甘、涩",jing:"心、肝、肾",act:"镇惊安神、平肝潜阳",dims:"d3内入 d7内守 d9潜"},
 "牡蛎":{qi:"微寒",wei:"咸",jing:"肝、肾",act:"重镇安神、潜阳、软坚",dims:"d7软坚 d9潜"},
 "五味子":{qi:"温",wei:"酸、甘",jing:"肺、心、肾",act:"收敛固涩、益气生津",dims:"d7收敛 d3固涩"},
 "乌梅":{qi:"平",wei:"酸、涩",jing:"肝、脾、肺、大肠",act:"敛肺涩肠、生津安蛔",dims:"d7收敛 d3固"},
 "香附":{qi:"平",wei:"辛、微苦",jing:"肝、脾、三焦",act:"疏肝解郁、理气宽中",dims:"d6疏达 d7条达"},
 "郁金":{qi:"寒",wei:"辛、苦",jing:"肝、心、肺",act:"活血止痛、行气解郁",dims:"d6通 d5清"},
 "麦冬":{qi:"微寒",wei:"甘、微苦",jing:"心、肺、胃",act:"养阴生津、润肺清心",dims:"d3滋 d4微清"},
 "竹茹":{qi:"微寒",wei:"甘",jing:"肺、胃、心、胆",act:"清热化痰、除烦止呕",dims:"d5化浊 d4清"},
 "肉桂":{qi:"热",wei:"辛、甘",jing:"肾、脾、心、肝",act:"补火助阳、引火归元",dims:"d4升 d9温通",preg:"慎用",tox:"十九畏(官桂畏石脂)"},
 "吴茱萸":{qi:"热",wei:"辛、苦",jing:"肝、脾、胃、肾",act:"散寒止痛、降逆止呕",dims:"d4升 d9降逆",tox:"小毒"},
 "细辛":{qi:"温",wei:"辛",jing:"心、肺、肾",act:"解表散寒、祛风止痛",dims:"d3开 d9宣",tox:"小毒 反藜芦"},
 "紫菀":{qi:"温",wei:"辛、苦",jing:"肺",act:"润肺下气、化痰止咳",dims:"d6肺降 d5化浊"}
};

/* ---------- 7. 配伍禁忌（Excel·配伍禁忌表，结构化[补充]） ---------- */
DATA.contra = {
 shibaFan: [ /* 十八反：硬拦截 */
   {a:"甘草", b:["甘遂","大戟","海藻","芫花"], why:"甘草+d7调和试图统一全局，反药强效逐水破坏d7根基，对d7秩序作用方向相反", risk:"d7秩序 d1本体"},
   {a:"乌头", b:["半夏","瓜蒌","贝母","白蔹","白及"], why:"乌头+d4大热大散，半夏+d7降逆，热降相激扰乱d4/d7平衡", risk:"d4能量 d7秩序"},
{a:"川乌", b:["半夏","瓜蒌","贝母","白蔹","白及"], why:"同乌头类", risk:"d4能量 d7秩序"},
    {a:"草乌", b:["半夏","瓜蒌","贝母","白蔹","白及"], why:"同乌头类", risk:"d4能量 d7秩序"},
    {a:"附子", b:["半夏","瓜蒌","贝母","白蔹","白及"], why:"附子为乌头类炮制品，与半夏相反，热降相激扰乱d4/d7平衡", risk:"d4能量 d7秩序"},
   {a:"藜芦", b:["人参","沙参","丹参","玄参","细辛","芍药"], why:"藜芦催吐攻邪耗d1，参类补益扶正建d1，补泻同施扰乱d1本体", risk:"d1本体 d9行动"}
 ],
 shijiuWei: [ /* 十九畏 */
   ["硫黄","朴硝"],["水银","砒霜"],["狼毒","密陀僧"],["牙硝","三棱"],["官桂","石脂"],
   ["人参","五灵脂"],["川椒","黄连"],["黑锡","火硝"],["人参","皂角"],["大黄","密陀僧"]
 ],
 xiangE: [ ["人参","莱菔子"] ],
 pregForbid: ["巴豆","牵牛","大戟","商陆","麝香","三棱","莪术","水蛭","虻虫"],
 pregCaution: ["大黄","桃仁","红花","冬瓜仁","肉桂","附子","干姜","牛膝","台乌","半夏","枳实","芒硝"],
 daDu: ["生附子","川乌","草乌","巴豆"],
 youDu: ["生半夏","天南星","商陆","甘遂"],
 xiaoDu: ["防己","苦杏仁","吴茱萸","细辛"]
};

/* ---------- 8. 药性→维度加减建议表 [补充]（据§15药性向量映射生成） ---------- */
DATA.dimAdvice = {
 /* dim索引0-8 → {低(0态)建议, 高(2态)建议} */
 0:{low:{herbs:["人参","黄芪","炙甘草","山药"], act:"甘温补中，重建d1本体根基"},
    high:{herbs:["白芍","麦冬"], act:"柔润缓急，软化d1刚性代偿"}},
 1:{low:{herbs:["当归","川芎"], act:"温通活血，唤醒沉滞节律"},
    high:{herbs:["酸枣仁","龙骨"], act:"安定收敛，缓解紧迫过速"}},
 2:{low:{herbs:["麻黄","桂枝","柴胡"], act:"辛散升提，打开d3表闭/塌陷空间（表闭用麻桂，中陷用柴升）"},
    high:{herbs:["白芍","五味子","龙骨","牡蛎"], act:"酸收沉降，固护耗散外越之空间"}},
 3:{low:{herbs:["附子","干姜","肉桂","黄芪"], act:"辛热温阳，升发d4能量（附子须炮制、中病即止）"},
    high:{herbs:["石膏","黄连","黄芩","栀子"], act:"苦寒直折，清泄d4亢盛实热"}},
 4:{low:{herbs:["石菖蒲类开窍思路","郁金"], act:"行气解郁开窍，疏通d5信息闭塞"},
    high:{herbs:["黄连","竹茹","龙骨"], act:"清心降火，镇摄d5信息过载"}},
 5:{low:{herbs:["柴胡","香附","郁金"], act:"疏肝理气，恢复d6枢转与连接"},
    high:{herbs:["龙骨","牡蛎"], act:"重镇潜阳，收敛d6过度纠缠"}},
 6:{low:{herbs:["人参","白术","炙甘草"], act:"甘温建中，立d7运化秩序"},
    high:{herbs:["大黄","芒硝","厚朴"], act:"咸苦软坚通泄，破d7僵化燥结"}},
 7:{low:{herbs:["人参","大枣","炙甘草"], act:"补养锚定，重建d8意义方向"},
    high:{herbs:["麦冬","白芍"], act:"滋阴柔润，化解d8过度执取"}},
 8:{low:{herbs:["黄芪","人参","桂枝"], act:"补气助阳，启动d9有序行动"},
    high:{herbs:["白芍","五味子","牡蛎"], act:"酸敛潜镇，收敛d9亢奋耗散"}}
};

/* ---------- 9. 演化规则 / 诊断指标 / 治则（知识库展示，Excel原表） ---------- */
DATA.evoRules = [
 {t:"本体约束", d:"d1决定系统是否允许其他维度大幅变化。d1过低则其他维度变化被抑制；d1过高且d7不足则滑向失序", f:"若d1=0 → d4/d9/d5变化被抑制；若d1=2且d7<1 → 显化→失序", s:"补中益气汤先补d1再升举"},
 {t:"对立耦合", d:"四组维度天然成对，差值过大会产生恢复力；差值适中可形成推进力", f:"|d2-d3|、|d4-d5|、|d6-d7|、|d8-d9| 不宜过大", s:"桂枝汤中桂枝(开)与芍药(合)配对"},
 {t:"中介传导", d:"1不是弱，而是转换通道。维度不能直接从0跳2或2回0，必须经过1", f:"0→1→2；2→1→0；1→0/2", s:"亢奋耗散恢复时先开d3空间再降d9行动"},
 {t:"层级递进", d:"九维分三层，演化由内向外传导。内核层变化慢但影响深，表达层变化快但易回撤", f:"内核层(d1,d2,d3)→动力层(d4,d5,d6,d7)→表达层(d8,d9)", s:"补中益气汤：先补d1/d4→再建d7→再开d3→最后恢复d9"},
 {t:"场域共振", d:"19683状态中并非每个都稳定。稳定吸引子需多维协同、差值适中、中介充分", f:"稳定条件：多维协同+耦合差值适中+中介通道充分", s:"中和吸引子：多数维在1，少量在0或2"},
 {t:"状态更新", d:"新状态 = 当前状态 + 牵引力 − 阻力 + 噪声", f:"牵引力：目标/耦合维/内核层；阻力：差值过大/中介缺失/本体不足", s:"桂枝汤证：d3先升→d7再升→d9后降"}
];
DATA.metrics = [
 {n:"张力指数", f:"|d2-d3|+|d4-d5|+|d6-d7|+|d8-d9|", m:"系统内部摩擦程度，差值越大内耗越严重", t:"≥6高风险；≥4警惕；<4正常", a:"张力过高→优先回中和吸引子，修复耦合平衡"},
 {n:"显化势能", f:"(d1+d4+d8+d9)/4 × w(d7)", m:"向外输出能力。势能高但秩序低=虚火", t:">1.5且d7<1为虚火；>1.5且d7≥1可显化", a:"虚火时不宜强显化，先建秩序d7"},
 {n:"中介通畅度", f:"处于值1的维度数 / 9", m:"系统可调节性和弹性，1越多越有弹性", t:"≥7弹性好；4-6一般；<4僵化/极端", a:"通畅度低→先恢复1通道(如开空间d3)"},
 {n:"本体稳固系数", f:"(d1+d7+d8)/3", m:"本体+秩序+价值协同决定抗扰动能力", t:"≥1稳固；<1脆弱；≤0.5极脆弱", a:"本体脆弱时禁用强攻/强发汗/强显化"}
];
DATA.zefa = [
 {n:"汗法", op:"+d3表开 +d9有序外解", st:"表实证", f:"麻黄汤/桂枝汤", contra:"表虚自汗忌；阴虚/亡血者慎用"},
 {n:"吐法", op:"+d9强上逆 +d5涌吐", st:"痰涎壅塞胸膈、食积胃脘", f:"瓜蒂散", contra:"体虚/孕妇忌吐"},
 {n:"下法", op:"+d3通里 +d9下行 +d7通泄", st:"里实证(燥屎/积水/实热)", f:"大承气汤", contra:"表证未解忌下；孕妇/体虚忌下"},
 {n:"和法", op:"+d6枢转 +d7秩序 d4清透", st:"半表半里证(少阳病)", f:"小柴胡汤", contra:"纯表证/纯里证不宜"},
 {n:"温法", op:"+d4温升 +d1扶正 +d9温通", st:"寒证(实寒/虚寒)", f:"四逆汤/理中丸", contra:"热证忌温；阴虚内热忌温"},
 {n:"清法", op:"-d4热 -d5浊 d9凉血", st:"热证(实热/虚热/毒热)", f:"白虎汤/龙胆泻肝汤", contra:"脾胃虚寒忌清；真寒假热忌清"},
 {n:"消法", op:"+d7疏通 +d9消导 d5化浊", st:"积聚痞块(痰饮/瘀血/食积)", f:"血府逐瘀汤", contra:"体虚慎用；孕妇忌破血消癥"},
 {n:"补法", op:"+d1补 +d4升 +d8养 +d7巩固", st:"虚证(气/血/阴/阳虚)", f:"补中益气汤/六味地黄丸", contra:"实证忌补；实邪未去忌补"},
 {n:"固涩法", op:"+d7封藏 -d9外散 +d3固边界", st:"滑脱不禁(自汗/久泻/遗精)", f:"金匮肾气丸类", contra:"实邪未清忌固涩；闭门留寇之戒"},
 {n:"安神法", op:"+d7安定 +d8价值锚定 d5清透", st:"心神不宁(心悸/失眠/惊狂)", f:"酸枣仁汤/桂甘龙牡汤", contra:"实热扰心慎用温补安神"}
];
DATA.yaoxing = [
 {c:"四气·寒", op:"d4降(清热) d5清透", ex:"黄连 黄芩 栀子 石膏", note:"寒凉过度伤d1中阳；脾胃虚寒忌"},
 {c:"四气·热", op:"d4升(温阳) d9温通", ex:"附子 干姜 肉桂 吴茱萸", note:"温热过度耗d3阴液；阴虚阳亢忌"},
 {c:"四气·温", op:"d4温和升 d9温和通", ex:"桂枝 生姜 黄芪 人参", note:"温而不燥，最为平和"},
 {c:"四气·凉", op:"d4微降 d5微清", ex:"金银花 连翘 薄荷", note:"凉而不寒，适合温病初起"},
 {c:"五味·辛", op:"d3开表 d9宣散", ex:"麻黄 桂枝 生姜", note:"辛散过度耗d1正气；表虚自汗忌"},
 {c:"五味·甘", op:"d1补中 d7调和 d8养", ex:"甘草 大枣 人参 黄芪", note:"甘缓过度生d5湿滞；中满忌"},
 {c:"五味·酸", op:"d7收敛 d3固涩", ex:"乌梅 五味子 山茱萸 白芍", note:"酸收敛邪；表证未解忌"},
 {c:"五味·苦", op:"d4降泄 d5清泄 d7肃降", ex:"黄连 黄柏 大黄 栀子", note:"苦寒过度伤d1胃气"},
 {c:"五味·咸", op:"d7软坚 d3散结", ex:"芒硝 海藻 牡蛎", note:"咸寒伤d1中阳"},
 {c:"五味·淡", op:"d7渗湿 d5利浊", ex:"茯苓 猪苓 泽泻", note:"淡渗利湿，过用伤阴"},
 {c:"升", op:"d3上升 d6升提", ex:"升麻 柴胡 桔梗 防风", note:"升提太过致d1浮越；气逆忌"},
 {c:"降", op:"d9降逆 d7肃降", ex:"杏仁 半夏 代赭石", note:"降逆太过致气陷"},
 {c:"浮", op:"d3外达 d9发散", ex:"薄荷 荆芥 蝉蜕 桑叶", note:"浮散太过耗气；表虚忌"},
 {c:"沉", op:"d3内入 d7内守", ex:"牡蛎 龙骨 磁石", note:"沉涩太过碍运化"}
];

/* ============================================================
 * 三元九维中医辨证推演系统 · 推演引擎
 * 实现《编码规则》§10量化诊断、§9吸引子切换、§11状态迁移算法(11步)
 * ============================================================ */
"use strict";

const Engine = (() => {
  const W = [1.5, 1, 1.5, 1, 1, 1, 1.5, 1, 1]; // 承载维度 d1/d3/d7 加权 (§11.3)
  const T = [1,1,1,1,1,1,1,1,1];                 // 中和目标态
  const COUPLES = [[1,2],[3,4],[5,6],[7,8]];     // 时位/能信/群序/知行 (0-based)
  const COUPLE_NAMES = ["时位耦合(d2·d3)","能信耦合(d4·d5)","群序耦合(d6·d7)","知行耦合(d8·d9)"];
  const ATTRACTOR_ORDER = ["中和","枢转","潜藏","升举","显化","关系"]; // 同分优先级(切换顺序§9.1)

  /* ---- 步骤1：症状+标签 → 九维状态向量 S (§12.3 辨证即诊断) ---- */
  function aggregateState(selectedSymptoms, selectedTags, ctx) {
    const votes = [0,0,0,0,0,0,0,0,0];
    const traces = []; // 可解释性记录
    selectedSymptoms.forEach(s => {
      if (!s.v) return;
      Object.keys(s.v).forEach(k => {
        const d = +k; votes[d] += s.v[d];
        traces.push(`${s.n} → ${DATA.dimensions[d].key}${s.v[d]>0?"↑显":"↓潜"}(${Math.abs(s.v[d])})`);
      });
    });
    // 宏观辨证标签：典型状态向量锚定（八纲权重1，六经/体质权重2）
    selectedTags.forEach(t => {
      const w = t.w || 2;
      t.vec.forEach((val, d) => {
        if (val !== 1) { votes[d] += (val - 1) * w; traces.push(`${t.n}锚定 → ${DATA.dimensions[d].key}=${val}`); }
      });
    });
    // 久病/新病对d2的修正已含在情境条目中
    const S = votes.map(v => v >= 1.5 ? 2 : (v <= -1.5 ? 0 : 1));
    const strength = votes.map(v => Math.min(Math.abs(v), 4)); // 判定强度(展示用)
    return {S, votes, strength, traces};
  }

  /* ---- 步骤2：偏差与量化诊断指标 (§10) ---- */
  function diagnose(S) {
    const delta = S.map((v,i)=>v-T[i]);
    const E = delta.reduce((a,b)=>a+Math.abs(b),0);
    const coupleDiff = COUPLES.map(([a,b])=>Math.abs(S[a]-S[b]));
    const tension = coupleDiff.reduce((a,b)=>a+b,0);
    const ones = S.filter(v=>v===1).length;
    const fluidity = ones/9;
    // 显化势能：w(d7)秩序加权 —— d7=0→0.6, d7=1→1.0, d7=2→1.2 [补充实现]
    const w7 = [0.6, 1.0, 1.2][S[6]];
    const potential = ((S[0]+S[3]+S[7]+S[8])/4) * w7;
    const stability = (S[0]+S[6]+S[7])/3;
    const levels = { // 三层结构评估
      core: (S[0]+S[1]+S[2])/3, power: (S[3]+S[4]+S[5]+S[6])/4, express: (S[7]+S[8])/2
    };
    // 指标联动规则 (§10.2)
    const links = [];
    if (tension>=4 && fluidity<4/9) links.push("张力指数高+中介通畅度低：系统高度僵化，必须优先恢复中介通道（如开空间d3）");
    if (potential>1.5 && stability<1) links.push("显化势能高+本体稳固系数低：虚火状态，强显化将加速耗散");
    if (stability<1 && tension>=4) links.push("本体不稳+张力高：基础不牢且内耗严重，属最危险组合，先固本体");
    if (fluidity>=7/9 && tension<4) links.push("中介通畅+张力低：系统健康可调节，可选择方向性吸引子");
    // 阻滞判定 (§6.3)
    const blocks = [];
    if (S[5]>=2 && S[6]===0) blocks.push("d6关系已到2而d7秩序仍为0：关系网络缺乏结构，易纠缠混乱");
    if (S[4]===2 && S[3]===0) blocks.push("d5信息已到2而d4能量仍为0：认知清楚却无力执行，易空转焦虑");
    if (S[8]===2 && S[7]===0) blocks.push("d9行动已到2而d8价值仍为0：行为变成重复消耗，易倦怠放弃");
    if (S[0]===0 && S[8]===2) blocks.push("d1本体为0而d9行动为2：根基不稳却高强度输出，易突然崩溃");
    // 耦合警示
    const coupleWarn = coupleDiff.map((dv,i)=> dv>=2 ? `${COUPLE_NAMES[i]}差值${dv}：明显恢复力已启动，属主要矛盾之一` : null).filter(Boolean);
    return {delta, E, tension, coupleDiff, coupleWarn, fluidity, potential, stability, levels, links, blocks};
  }

  /* ---- 步骤3：吸引子判别 (§9.2 简化判定流程，模糊适配度打分[补充]) ----
   * 宏观辨证标签对吸引子的先验加成[补充]：依据Excel三张映射表
   * （六经→吸引子、体质→代表方→吸引子） */
  const ATTR_TAG_BOOST = {
    "太阳病":["显化",2], "阳明病":["显化",2], "少阳病":["枢转",3],
    "太阴病":["潜藏",3], "少阴病":["潜藏",3], "厥阴病":["枢转",2],
    "平和质":["中和",4], "气虚质":["升举",3], "阳虚质":["潜藏",3],
    "阴虚质":["潜藏",3], "痰湿质":["中和",2], "湿热质":["显化",3],
    "血瘀质":["枢转",3], "气郁质":["枢转",3], "特禀质":["中和",2],
    "表证":["显化",2], "里证":["中和",1], "寒证":["潜藏",2], "热证":["显化",2],
    "虚证":["潜藏",2], "实证":["显化",2], "阴证":["潜藏",2], "阳证":["显化",2]
  };
  function matchAttractor(S, dx, ctx) {
    const [d1,d2,d3,d4,d5,d6,d7,d8,d9]=S;
    const lowCount = [d3,d7,d8].filter(v=>v===0).length;
    const yinXu = d4===2 && d3===0;           // 阴虚阳浮特征
    const yangXu = d4===0 && d1===0;           // 阳虚寒盛特征
    const fit = {"中和":0,"潜藏":0,"升举":0,"枢转":0,"显化":0,"关系":0};
    fit["中和"] = (dx.tension>=4?3:0) + (dx.E>=5&&dx.fluidity<4/9?2:0) + (lowCount>=2&&dx.tension>=2?2:(lowCount>=2?1:0));
    fit["潜藏"] = ((d4===2||d9===2)&&(d1===0||d3===0)?3:0) + (yinXu?3:0) + (yangXu?2:0) + (d9===2&&d8<=1?1:0) + (d1===0&&d4===0&&d8===0?3:0);
    fit["升举"] = ([d1,d4,d7,d9].filter(v=>v===0).length>=3?4:0) + (d1===0&&d9===0?2:0) + (d8>=1&&d9===0?1:0);
    fit["枢转"] = (d6===0&&d7===0) ? (4+(d3===1?1:0)+(d2>=1?1:0))
                : (d6===0&&d3===1) ? 2
                : (d7===0&&d6<=1&&d3===1) ? 1 : (d6===0||d7===0 ? 0 : -2);
    const xianHuaGate = (d4===2) || (d3===0&&d2===2) || (d5===2&&d4>=1);
    fit["显化"] = xianHuaGate ? ((d1>=1&&d7>=1&&d8>=1?2:0) + (d3===0&&d2===2?2:0) + (d4===2&&d5===2?3:0) + (d4===2&&d7>=1?1:0)) : 0;
    fit["关系"] = (d6===0&&d1>=1&&d7>=1?3:0) + (d6===0&&d8>=1?1:0) + (d1===0?-2:0);
    // 宏观标签先验加成
    if (ctx){
      ctx.tags.concat(ctx.liujing||[], ctx.tizhi||[]).forEach(t=>{
        const b = ATTR_TAG_BOOST[t];
        if (b) fit[b[0]] += b[1];
      });
    }
    let best=null, bestScore=-99;
    ATTRACTOR_ORDER.forEach(name=>{ // 依优先级顺序遍历，严格大于才替换→同分取高优先
      if (fit[name]>bestScore){bestScore=fit[name];best=name;}
    });
    if (bestScore<=0){best="中和";bestScore=0;} // 兜底：系统乱/无明显方向，先回中和
    const info = DATA.attractors.find(a=>a.name===best);
    return {name:best, score:bestScore, fit, info};
  }

  /* ---- 步骤4-8：方剂检索、评分、禁忌惩罚、Top-K (§11.2/11.3) ---- */
  function patternFlags(S, ctx) {
    const [d1,d2,d3,d4,d5,d6,d7,d8,d9]=S;
    return {
      yinXu: d4===2 && d3===0,               // 阴虚阳浮
      yangXuHan: d4===0 && (d1===0||d3===0),  // 阳虚寒盛/脾胃虚寒
      shiRe: d4===2 && d5===2,                // 实热壅盛
      shiZheng: S.filter(v=>v===2).length>=4, // 邪气盛实
      biaoZheng: ctx.tags.includes("表证") || ctx.liujing.includes("太阳病"),
      /* v1.1：症状级标签透传（P2/P5）——"表虚/表实/瘀/寒/热"等出现在症状 tag 或宏观标签中均生效 */
      biaoxu: ctx.tags.includes("表虚") || (ctx.symTags||[]).includes("表虚"),
      bleeding: ctx.bleeding
    };
  }

  /* 方剂证候关键词表[补充]：用于宏观标签与方剂适用辨证的互证加分 */
  const FORMULA_KEYWORDS = {
    "桂枝汤":["表虚","太阳","营卫","表证"],
    "六味地黄丸":["阴虚","肾阴","虚火","热证"],
    "麻黄汤":["表实","表证","太阳","风寒","寒证","实证"],
    "小柴胡汤":["少阳","半表半里","气郁"],
    "补中益气汤":["气虚","虚证","太阴","里证"],
    "四逆汤":["寒证","阴证","阳虚","少阴","虚证"],
    "理中丸":["寒证","太阴","虚证","里证","阴证"],
    "逍遥散":["气郁","肝郁","血瘀","里证"],
    "血府逐瘀汤":["血瘀","瘀","气郁"],
    "补阳还五汤":["血瘀","瘀","气虚","中风"],
    "龙胆泻肝汤":["湿热","热证","实证","阳证"],
    "茵陈蒿汤":["湿热","黄疸","热证","实证"],
    "白虎汤":["热证","实热","阳证","阳明","实证"],
    "大承气汤":["实证","实热","阳明","里证","热证"]
  };

  function scoreFormulas(S, dx, attractor, ctx) {
    const pf = patternFlags(S, ctx);
    const results = [];
    DATA.formulas.forEach(f => {
      let score = 0, hard = [], warns = [];
      // (1) 向量距离：方剂九维向量=其主治证型的典型状态，越接近得分越高
      let dist = 0;
      for (let i=0;i<9;i++) dist += W[i]*Math.abs(S[i]-f.vec[i]);
      score -= dist;
      // (2) 吸引子契合
      if (f.attractor === attractor.name) score += 4;
      // (3) 宏观标签契合（关键词互证，封顶+4）
      let tagBonus = 0;
      ctx.tags.concat(ctx.liujing, ctx.tizhi).forEach(t=>{
        (FORMULA_KEYWORDS[f.name]||[]).forEach(k=>{
          if (t.includes(k) && tagBonus<4){ tagBonus+=2; }
        });
      });
      score += tagBonus;
      // (3b) 证候指征不足降权[补充]：主证未显则不宜投方（源自各方"禁忌条件"）
      if (f.name==="麻黄汤" && !(S[1]===2||S[2]===0||pf.biaoZheng)) warns.push({t:"表寒证指征不足（无表闭/脉浮紧象）", p:4});
      if (f.name==="桂枝汤" && S[5]!==2 && S[6]!==0) warns.push({t:"营卫不和指征不足", p:3});
      if (f.name==="六味地黄丸" && !(S[3]===2||pf.yinXu)) warns.push({t:"肾阴虚指征不足", p:3});
      if (f.name==="白虎汤" && S[3]!==2) warns.push({t:"气分大热未显（d4≠2），不宜辛寒重剂", p:4});
      if (f.name==="大承气汤" && !(S[6]===2&&S[8]===2&&S[3]===2)) warns.push({t:"痞满燥实坚未俱备，峻下须慎", p:5});
      if (f.name==="四逆汤" && !(S[3]===0&&S[8]===0)) warns.push({t:"阳衰厥逆指征不足", p:4});
      if (f.name==="龙胆泻肝汤" && !(S[3]===2||S[4]===2)) warns.push({t:"肝胆实火/湿热指征不足", p:4});
      if (f.name==="茵陈蒿汤" && !(S[3]===2&&S[4]>=1)) warns.push({t:"湿热黄疸指征不足", p:4});
      if (f.name==="补中益气汤" && !(S[0]===0&&S[8]===0)) warns.push({t:"中气下陷指征不足", p:3});
      if (f.name==="血府逐瘀汤" && !(S[5]===0||S[6]===0||ctx.tags.includes("血瘀质"))) warns.push({t:"血瘀指征不足", p:3});
      if (f.name==="补阳还五汤" && !((ctx.symTags||[]).includes("瘀")||ctx.tizhi.includes("血瘀质"))) warns.push({t:"血瘀指征不足（无瘀血症状/体征支持）", p:3});
      if (f.name==="理中丸" && !(S[3]===0&&S[0]<=1)) warns.push({t:"中焦虚寒指征不足", p:3});
      // (4) 禁忌审查：硬拦截 + 惩罚P (§11.4 配伍约束)
      const stab = dx.stability;
      if (ctx.pregnant) {
        if (f.flags.preg==="forbid") hard.push("妊娠禁用（破血/峻下，d9剧烈行动+d3空间动荡）");
        else if (f.flags.preg==="caution") warns.push({t:"妊娠慎用（含活血/攻下药）", p:5});
      }
      if (stab<=0.5 && (f.flags.strongAttack||f.flags.strongSweat||f.flags.strongManifest))
        hard.push("本体稳固系数≤0.5（极脆弱），禁强攻/强发汗/强显化");
      if (S[0]===0 && f.flags.strongManifest) hard.push("d1=0：本体闸门关闭，禁用强显化方");
      if (f.name==="桂枝汤" && S[8]===0 && S[2]===0) warns.push({t:"d9=0且d3=0：表闭无汗不宜桂枝汤", p:5});
      if (f.name==="麻黄汤") {
        if (pf.biaoxu) hard.push("表虚自汗忌用");
        if (pf.yinXu) warns.push({t:"阴虚阳亢慎用", p:4});
        if (pf.bleeding) hard.push("衄血/出血倾向者忌用");
      }
      if (f.name==="六味地黄丸") {
        if (pf.yangXuHan) hard.push("阳虚寒盛忌用");
        if (S[4]===2&&S[6]<=0) warns.push({t:"脾虚湿盛慎用", p:3});
        if (pf.biaoZheng) warns.push({t:"表证未解不宜", p:4});
      }
      if (f.name==="小柴胡汤") {
        if ((pf.biaoZheng && S[2]!==1) || S.filter(v=>v===2).length>=5) warns.push({t:"纯表证/纯里证或实热壅盛不宜", p:4});
      }
      if (f.name==="补中益气汤") {
        if (pf.shiZheng) hard.push("实证忌用");
        if (pf.yinXu) warns.push({t:"阴虚阳亢忌用", p:4});
        if (S[2]===2&&S[6]===2) warns.push({t:"气滞胀满慎用", p:3});
        if (pf.biaoZheng&&S[3]>=1) warns.push({t:"外感发热忌用", p:4});
      }
      if (f.name==="四逆汤") {
        if (pf.yinXu) hard.push("阴虚阳亢忌用");
        if (pf.shiRe) hard.push("真热假寒忌用");
      }
      if (f.name==="理中丸" && pf.shiRe) hard.push("实热积滞忌用");
      if (f.name==="逍遥散" && pf.shiRe) warns.push({t:"湿热内蕴忌；阴虚火旺慎用", p:4});
      if (f.name==="血府逐瘀汤" && pf.bleeding) warns.push({t:"出血倾向慎用", p:5});
      if (f.name==="补阳还五汤") {
        if (pf.yinXu) warns.push({t:"阴虚阳亢忌", p:5});
        if (pf.bleeding) warns.push({t:"出血急性期慎用", p:5});
      }
      if (f.name==="龙胆泻肝汤") {
        if (pf.yangXuHan) hard.push("脾胃虚寒忌");
        if (pf.yinXu) warns.push({t:"阴虚津伤忌", p:4});
      }
      if (f.name==="茵陈蒿汤" && S[3]===0&&S[4]<=0) hard.push("寒湿黄疸（阴黄）忌用");
      if (f.name==="白虎汤") {
        if (S[3]===0) hard.push("阳明虚寒忌用");
        if (pf.biaoZheng && S[2]>=1) warns.push({t:"表证未解忌单用", p:4});
      }
      if (f.name==="大承气汤") {
        if (pf.biaoZheng && S[2]>=1) hard.push("表证未解忌下");
        if (stab<1) warns.push({t:"体虚慎用（本体稳固系数<1）", p:5});
      }
      // 全局：d9不能从0直接跳2（配伍约束）——强动d9的方在d9=0时降权
      if (S[8]===0 && f.vec[8]===2) warns.push({t:"d9=0不可直跳2，需经中介过渡，牵引须分步", p:2});
      const P = warns.reduce((a,w)=>a+w.p,0);
      score -= P;
      results.push({f, score:Math.round(score*10)/10, dist:Math.round(dist*10)/10, P, hard, warns,
        attrBonus: f.attractor===attractor.name});
    });
    const passed = results.filter(r=>r.hard.length===0).sort((a,b)=>b.score-a.score);
    const blocked = results.filter(r=>r.hard.length>0);
    return {passed, blocked};
  }

  /* ---- 步骤5：牵引路径生成 (§11.2 层级递进：先d1/d7/d3→d6/d5→d4→d8/d2/d9) ---- */
  const PATH_ORDER = [0,6,2,5,4,3,7,1,8];
  function buildPath(S) {
    const steps = [], cur = S.slice();
    PATH_ORDER.forEach(d => {
      while (cur[d] !== 1) {
        const dir = cur[d] > 1 ? -1 : +1;
        const from = cur[d];
        cur[d] += dir;
        const to = cur[d];
        const dim = DATA.dimensions[d];
        const bridgeWhy = from===0
          ? `${dim.name}处于潜态(0)，先升入中介通道1，不可直跳显态2`
          : `${dim.name}处于显态(2)，先收敛回中介通道1，不可直落潜态0`;
        steps.push({
          dim: d, key: dim.key, name: dim.name,
          from: from, to: to,
          text: `${dim.key}${dim.name}：${from}(${dim.states[from].split("/")[0]}) → ${to}(${dim.states[to].split("/")[0]})`,
          why: `${dir>0?`升发${dim.name}`:`收敛${dim.name}`}，${bridgeWhy}`
        });
      }
    });
    return steps;
  }

  /* ---- 步骤9：药味加减建议（剩余偏差→药性向量映射§15） ---- */
  function buildAdvice(S, topFormula) {
    const advice = [];
    S.forEach((v,d)=>{
      if (v===1) return;
      const a = v===0 ? DATA.dimAdvice[d].low : DATA.dimAdvice[d].high;
      advice.push({dim:d, key:DATA.dimensions[d].key, name:DATA.dimensions[d].name,
        state:v, dir:v===0?"偏低(0态)":"偏高(2态)", herbs:a.herbs, act:a.act});
    });
    return advice;
  }

  /* ---- 步骤10：配伍禁忌审查（十八反/十九畏/妊娠/毒性） ---- */
  function checkCompat(herbList, ctx) {
    const issues = [], set = new Set(herbList);
    const has = n => set.has(n) || herbList.some(h=>h.includes(n)||n.includes(h));
    DATA.contra.shibaFan.forEach(r=>{
      if (has(r.a)) r.b.forEach(b=>{ if(has(b)) issues.push({lv:"反", t:`${r.a} 反 ${b}`, why:r.why, risk:r.risk}); });
    });
    DATA.contra.shijiuWei.forEach(([a,b])=>{
      if (has(a)&&has(b)) issues.push({lv:"畏", t:`${a} 畏 ${b}`, why:"药性剧烈互相制约，可能产生毒性或失效"});
    });
    DATA.contra.xiangE.forEach(([a,b])=>{
      if (has(a)&&has(b)) issues.push({lv:"恶", t:`${a} 恶 ${b}`, why:"相恶：一药减另一药疗效"});
    });
    if (ctx.pregnant) {
      DATA.contra.pregForbid.forEach(h=>{ if(has(h)) issues.push({lv:"妊娠禁用", t:`妊娠禁用 ${h}`, why:"强攻逐水破血，d9剧烈行动+d3空间动荡，可致堕胎"}); });
      DATA.contra.pregCaution.forEach(h=>{ if(has(h)) issues.push({lv:"妊娠慎用", t:`妊娠慎用 ${h}`, why:"活血/攻下/温里之品，影响d1/d3稳定，必要时慎用、中病即止"}); });
    }
    /* 毒性/峻烈提示（仅对实际入方的药给出，避免噪音）[补充] */
    const TOX_NOTES = {
      "附子":"大毒，须炮制先煎久煎，中病即止，不可久服（大毒治病十去其六）",
      "半夏":"生品有毒，须用制半夏；反乌头类（有毒治病十去其七）",
      "杏仁":"苦杏仁小毒，用量宜轻（小毒治病十去其八）",
      "细辛":"小毒，用量宜轻，不过钱（≤3g）",
      "大黄":"攻下伤胃气，中病即止，体虚者减量",
      "芒硝":"咸寒峻下，脾胃虚寒及妊娠忌",
      "麻黄":"发汗峻烈，过汗伤阳，表虚者忌",
      "龙胆草":"大苦大寒，易伤胃气，不宜久服"
    };
    herbList.forEach(h=>{
      if (TOX_NOTES[h]) issues.push({lv:"毒性提示", t:`${h}：${TOX_NOTES[h]}`, why:"注意炮制、用量与疗程"});
    });
    return issues;
  }

  /* ---- 步骤11：下一步状态 S1（施加首步牵引，检验平滑性） ---- */
  function nextState(S, steps, n=3) {
    const S1 = S.slice();
    steps.slice(0, n).forEach(st=>{ S1[st.dim] = st.to; });
    return S1;
  }

  /* ---- 主流程 ---- */
  function run(selectedSymptoms, selectedTags, ctx) {
    const agg = aggregateState(selectedSymptoms, selectedTags, ctx);
    const dx = diagnose(agg.S);
    const attractor = matchAttractor(agg.S, dx, ctx);
    const {passed, blocked} = scoreFormulas(agg.S, dx, attractor, ctx);
    const top = passed.slice(0, Math.min(3, passed.length)).map(r=>{
      const herbs = [].concat(r.f.jun, r.f.chen, r.f.zuo, r.f.shi);
      /* v1.1 P3：建议加味后的全方复查——原方 + 各维度加减建议含药（过滤"类/思路"占位符） */
      const advHerbs = buildAdvice(agg.S, r.f).flatMap(a=>a.herbs.filter(h=>!h.includes("类")&&!h.includes("思路")));
      const fullHerbs = herbs.concat(advHerbs.filter(h=>!herbs.includes(h)));
      return {...r, steps: buildPath(agg.S), compat: checkCompat(herbs, ctx),
        compatFull: checkCompat(fullHerbs, ctx),
        S1: nextState(agg.S, buildPath(agg.S)), advice: buildAdvice(agg.S, r.f)};
    });
    return {agg, dx, attractor, top, passed, blocked, ctx};
  }

  return {run, diagnose, aggregateState, buildPath, checkCompat, T, COUPLES, COUPLE_NAMES};
})();



const syms = DATA.symptomGroups.flatMap(g=>g.items);
const find = ns => ns.map(n=>{ const s=syms.find(x=>x.n===n); if(!s) console.log('WARN 症状缺失: '+n); return s; }).filter(Boolean);
const mkCtx = (o={})=>({pregnant:false, bleeding:false, tags:[], liujing:[], tizhi:[], symTags:[], ...o});
const tagObj = (src,n,w=2)=>{ const t=src.find(x=>x.n===n); return t?{n:t.n,vec:t.vec,w}:null; };

let pass=0, fail=0;
function check(name, cond, extra){
  if (cond){ pass++; console.log('PASS | '+name+(extra?' | '+extra:'')); }
  else { fail++; console.log('FAIL | '+name+(extra?' | '+extra:'')); }
}
function runCase(label, symNames, tagMap, tizhi, extra) {
  // tagMap: {bagang:[], liujing:[], tizhi:[]}
  const sel = find(symNames);
  const tagObjs = [];
  (tagMap.bagang||[]).forEach(n=>{const t=tagObj(DATA.bagang,n,1); if(t) tagObjs.push(t);});
  (tagMap.liujing||[]).forEach(n=>{const t=tagObj(DATA.liujing,n,2); if(t) tagObjs.push(t);});
  if (tizhi){ const t=tagObj(DATA.tizhi,tizhi,2); if(t) tagObjs.push(t); }
  const ctx = mkCtx({
    pregnant:!!(extra&&extra.pregnant), bleeding:!!(extra&&extra.bleeding),
    tags:(tagMap.bagang||[]).concat(tagMap.liujing||[]),
    tizhi: tizhi?[tizhi]:[],
    symTags: extra&&extra.symTags?extra.symTags:[]
  });
  return Engine.run(sel, tagObjs, ctx);
}
function brief(R){
  return {S:R.agg.S.join(','), E:R.dx.E, attr:R.attractor.name+'('+R.attractor.score+')',
    top:R.top.map(r=>r.f.name+'('+r.score+')').join(','),
    blocked:R.blocked.map(r=>r.f.name).join(',')};
}

console.log('===== v1.1 全量回归测试（对齐原始冒烟场景） =====\n');

// ---------- 典型证型（与 v1.0 审查冒烟完全一致） ----------
{
  const R = runCase('阳明热盛', ['发热身热','头胀头痛面红目赤','口淡不渴','便秘燥结','舌红苔黄','脉洪大','烦躁不安'],
    {bagang:['热证','阳证','实证'], liujing:['阳明病']}, null);
  const b = brief(R);
  check('阳明热盛: 吸引子=显化', R.attractor.name==='显化', b.attr);
  check('阳明热盛: 首推大承气汤', R.top[0]&&R.top[0].f.name==='大承气汤', b.top);
  check('阳明热盛: 硬拦截四逆/理中', ['四逆汤','理中丸'].every(n=>R.blocked.some(r=>r.f.name===n)), b.blocked);
}
{
  // 原始冒烟场景：症状 + 八纲(寒证/阴证/少阴病) + 阳虚质
  const R = runCase('少阴寒化(原始冒烟)', ['恶寒明显添衣不解','四肢厥冷','大便溏泄','小便清长','舌淡苔白','脉沉'],
    {bagang:['寒证','阴证'], liujing:['少阴病']}, '阳虚质');
  const b = brief(R);
  console.log('  [少阴寒化] S='+b.S+' attr='+b.attr+' top='+b.top);
  check('少阴寒化: S=0,1,0,0,1,0,0,0,0', R.agg.S.join(',')==='0,1,0,0,1,0,0,0,0', b.S);
  check('少阴寒化: 吸引子=潜藏', R.attractor.name==='潜藏', b.attr);
  check('少阴寒化: Top 含四逆汤', R.top.some(r=>r.f.name==='四逆汤'), b.top);
  check('少阴寒化: Top 含理中丸', R.top.some(r=>r.f.name==='理中丸'), b.top);
}
{
  const R = runCase('肝郁气滞', ['胸胁胀满','善太息情绪抑郁','脉弦','失眠多梦'],
    {bagang:['里证']}, '气郁质');
  const b = brief(R);
  check('肝郁气滞: 吸引子=枢转', R.attractor.name==='枢转', b.attr);
  check('肝郁气滞: Top 含逍遥散', R.top.some(r=>r.f.name==='逍遥散'), b.top);
}
{
  const R = runCase('阴虚火旺', ['五心烦热','潮热盗汗','失眠多梦','舌红绛少苔','脉细'], {}, '阴虚质');
  const b = brief(R);
  check('阴虚火旺: 吸引子=潜藏', R.attractor.name==='潜藏', b.attr);
  check('阴虚火旺: Top 含六味地黄丸', R.top.some(r=>r.f.name==='六味地黄丸'), b.top);
  check('阴虚火旺: 四逆被硬拦截', R.blocked.some(r=>r.f.name==='四逆汤'), b.blocked);
}
{
  const R = runCase('妊娠状态', ['妊娠状态','发热身热','便秘燥结','舌红苔黄'], {bagang:['热证']}, null, {pregnant:true});
  const b = brief(R);
  check('妊娠状态: 四逆/理中/血府逐瘀/大承气全拦截',
    ['四逆汤','理中丸','血府逐瘀汤','大承气汤'].every(n=>R.blocked.some(r=>r.f.name===n)), b.blocked);
}
{
  const R = runCase('中和态(空输入)', [], {}, '平和质');
  const b = brief(R);
  check('中和态: E=0', R.dx.E===0, 'E='+b.E);
  check('中和态: 吸引子=中和', R.attractor.name==='中和', b.attr);
}

// ---------- P2-P5/P7 定向验证 ----------
{
  const sel = find(['自汗恶风','脉浮','恶寒明显添衣不解']);
  const ctx = mkCtx({liujing:['太阳病'], symTags:['表虚']});
  const tagObjs = [tagObj(DATA.liujing,'太阳病')];
  const R = Engine.run(sel, tagObjs, ctx);
  const blk = R.blocked.find(r=>r.f.name==='麻黄汤');
  check('P2 表虚自汗: 麻黄汤硬拦截(表虚自汗忌用)', !!blk && blk.hard.some(h=>h.includes('表虚')), blk?blk.hard.join(';'):'未拦截');
  check('P2 表虚自汗: 麻黄汤不在通过候选', !R.passed.some(r=>r.f.name==='麻黄汤'));
}
{
  const sel = find(['寒热往来','胸胁胀满','恶心呕吐','腹痛喜温喜按','口淡不渴']);
  const ctx = mkCtx({liujing:['少阳病'], tizhi:['阳虚质'], symTags:['阳虚']});
  const tagObjs = [tagObj(DATA.liujing,'少阳病'), tagObj(DATA.tizhi,'阳虚质')].filter(Boolean);
  const R = Engine.run(sel, tagObjs, ctx);
  const top = R.top[0];
  check('P3 首推仍为小柴胡汤', top && top.f.name==='小柴胡汤', top?'score='+top.score:'');
  check('P3 compatFull 数组存在', !!top && Array.isArray(top.compatFull));
  const hasFuZi = top && top.compatFull.some(c=>c.t.includes('附子'));
  check('P3 全方复查含附子提示', !!hasFuZi, top?JSON.stringify(top.compatFull.map(c=>c.t)):'');
  check('P3 原方审查不含附子提示', !!top && !top.compat.some(c=>c.t.includes('附子')));
}
{
  const iss = Engine.checkCompat(['半夏','附子'], {pregnant:false});
  const fan = iss.filter(c=>c.lv==='反');
  check('P4 附子+半夏识别为反', fan.length>0, JSON.stringify(fan.map(c=>c.t)));
}
{
  const sel = find(['刺痛固定拒按','面色晦暗','舌紫暗有瘀斑','脉涩结代']);
  const ctx = mkCtx({symTags:['瘀']});
  const R = Engine.run(sel, [], ctx);
  const by = R.passed.find(r=>r.f.name==='补阳还五汤');
  const noWarn = by && !by.warns.some(w=>w.t.includes('血瘀指征不足'));
  check('P5 瘀血四症: 补阳还五汤无指征不足警告', !!noWarn, by?('score='+by.score):'未上榜');
}
{
  const R = Engine.run([], [], mkCtx());
  const steps = R.top[0]?R.top[0].steps:[];
  const hasOldText = steps.some(st=>st.why && st.why.includes('经中介通道1过渡'));
  check('P7 路径不再用旧固定文案', !hasOldText);
  if(R.top[0]) console.log('  [P7] 路径文案示例: '+JSON.stringify(R.top[0].steps.slice(0,2)));
}
{
  // P2/P5 根因：symTags 从症状 tag 聚合后传入引擎（app.js 层已实现，此处验证 engine 读取）
  const sel = find(['自汗恶风']).map(s=>s);
  const t = DATA.symptomGroups.flatMap(g=>g.items).find(s=>s.n==='自汗恶风');
  check('P2根因: 自汗恶风 tag=表虚', !!t && t.tag==='表虚', t?('tag='+t.tag):'');
  const tags = DATA.symptomGroups.flatMap(g=>g.items).filter(s=>['刺痛固定拒按','面色晦暗','舌紫暗有瘀斑','脉涩结代'].includes(s.n)).map(s=>s.tag);
  check('P5根因: 瘀血四症 tag 均为瘀', tags.every(x=>x==='瘀'), tags.join(','));
}

console.log('\n===== 结果: '+pass+' pass / '+fail+' fail =====');
if(fail>0) process.exit(1);
